/**
* Leon Parfenov
* IGME-102: Loops Review 1-3, 2/2/2021
*/ 

"use strict"; //catch some common coding errors

let pac = [];

//MY SETUP
 function setup() {
    createCanvas(600, 400);
    background("Red");
    angleMode(DEGREES);

     
    // for(let y=0; y<height/100; y+1){

    //     for(let x=0; x<width/100; x+1){
    //         pac.push(new Pac(100*x, 100*y));
    //     }
    // }

    //pac = new Pac(100, 100);
 }


 function draw() {

    

    //speed += pac;

    // for(let i=0; i<pac.length+1;i+1){
    // pac[i].update();
    // pac[i].display();
    // }
    
     
   /**  if (keyTyped == "2"){
        background("Black");
        fill("Yellow");
        stroke("Black");

        pac.update();
        pac.display();
    }
    

 }
 function keyTyped(){
    if(keyTyped =="1"){
        wordGrid();
     }
    if(keyTyped="2"){

        
    }

    **/
    }

 
